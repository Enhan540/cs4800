---
name: Kinetic Horizon
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464555'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#684000'
  on-tertiary: '#ffffff'
  tertiary-container: '#885500'
  on-tertiary-container: '#ffd4a4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes an approachable, warm, and hyper-legible environment tailored for social coordination: friend circles, tabletop adventuring parties, campus clubs, and civic volunteer squads. Traditional enterprise scheduling tools feel bureaucratic, anxiety-inducing, and sterile; this design system pivots sharply toward dynamic collaboration, communal momentum, and frictionless consensus.

### Personality & Core Attributes
- **Hospitable & Warm:** Interfaces prioritize welcoming layouts with humanizing details (prominent member avatars, conversational status states, and soft porcelain surfaces).
- **Decisive & Kinetic:** Clear, high-contrast visual cues eliminate decision paralysis. Availability states are instantly recognizable without cognitive strain.
- **Lightweight Modernism:** Generous negative space, rounded tactile elements, clean border micro-framing, and an absolute rejection of heavy administrative visual clutter.

### Visual Style Direction
The aesthetic fuses **Modern Tactile Minimalism** with **Social Micro-interactions**. The visual plane is composed of layered porcelain canvases, airy atmospheric backdrops, structured hairline boundaries, and vibrant focal points reserved strictly for user progression and affirmative attendance.

## Colors

The palette distinguishes purposeful actions from schedule heatmaps and availability states. Color is never decorative; it directly encodes operational state, personal commitment, and collective momentum.

### Color Distribution & Roles

- **Primary Interactive (#4F46E5 / #4338CA):** Vibrant Indigo reserved exclusively for high-intent interactive CTAs, focused text fields, progressive wizard steps, and active selection states.
- **Semantic Availability & Overlap (#10B981 / #059669 / #ECFDF5):** Fresh Emerald Mint signals common availability slots, high participant overlap, and confirmed time reservations.
- **RSVP Spectrum:**
  - *Attending (Confirmed):* Emerald Green (`#16A34A` text/icon on `#DCFCE7` fill).
  - *Partial (Late / Early / Flexible):* Mint Teal (`#0D9488` text/icon on `#CCFBF1` fill).
  - *Pending / Awaiting:* Warm Amber (`#D97706` text/icon on `#FEF3C7` fill).
  - *Declined / Unavailable:* Slate Gray (`#64748B` text/icon on `#F1F5F9` fill).
- **Destructive Action:** Soft Rose (`#E11D48` text on `#FFE4E6` background; solid `#E11D48` on hover) for event cancellation or slot removal, intentionally isolated from standard navigation flows.
- **Surfaces & Borders:** Warm Porcelain Canvas (`#FAFBFD`), Pure Elevated Surface (`#FFFFFF`), with hairline dividers utilizing `#E2E8F0` and `#EDF2F7`. High-contrast text uses Deep Slate (`#0F172A`) for headlines and Mid Slate (`#334155`) for secondary prose.

## Typography

The pairing blends the structured friendliness of **Plus Jakarta Sans** for headers, interactive anchors, and metric badges with the neutral legibility of **Inter** for multi-line context, details, and message threads.

### Typographic Application Rules
- **Display & Section Titles:** Render in Plus Jakarta Sans with subtle negative letter tracking (`-0.015em` to `-0.025em`) to retain punchiness and avoid an institutional corporate appearance.
- **Calendar & Matrix Grids:** Slot coordinates, time stamps, and calendar day labels utilize `label-md` and `label-sm` with upper/sentence casing and positive tracking (`0.02em`) to guarantee quick peripheral scanning.
- **Numerical Heatmaps & Quorum Tally:** Participant tallies (e.g., "7/8 Available") use `label-lg` with tabular figure variants (`font-variant-numeric: tabular-nums`) to prevent horizontal jitter during live sync updates.

## Layout & Spacing

The layout is built upon an 8pt modular grid with fluid breakpoints, organized to display both linear schedule agendas and dense matrix heatmaps without horizontal overflow friction.

### Responsive Breakpoint Architecture
- **Mobile (`< 640px`):** Single-column stacked stream. Margin: `margin` (`1rem`), column gutters: `gutter` (`1rem`). Availability matrices collapse into day-by-day swipe segments or consolidated vertical time blocks.
- **Tablet (`640px - 1024px`):** Dual-column layout. Margin: `margin-md` (`1.5rem`). Group meta details and member rosters pin adjacent to the central multi-day availability grid.
- **Desktop (`> 1024px`):** 12-column adaptive layout with an outer maximum container width of `1280px`. Margin: `margin-lg` (`2.5rem`), gutter: `gutter-lg` (`2rem`). Supports simultaneous display of real-time member roster filters, week-view heatmaps, and detail side-drawers.

### Spatial Rhythm
- Compact controls (chips, status pills, badge tallies) strictly utilize `space-xs` and `space-sm` internal padding.
- Interactive card interiors maintain consistent `space-md` on mobile and `space-lg` on larger displays to sustain a light, open atmosphere.

## Elevation & Depth

Visual depth is achieved through ambient, atmospheric light rather than structural shadows. Components maintain a floating yet tactile weight atop the porcelain canvas.

### Surface Hierarchy
- **Level 0 (Canvas Base):** Warm crisp porcelain (`#FAFBFD`). Non-interactive backdrop.
- **Level 1 (Card & Content Surface):** Solid pure white (`#FFFFFF`) with a 1px perimeter border (`#E2E8F0`) and an ultra-diffuse shadow: `0 1px 3px rgba(15, 23, 42, 0.04), 0 4px 8px -2px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Interactive Floating Overlays & Dropdowns):** `#FFFFFF` paired with hairline border (`#EDF2F7`) and elevated shadow: `0 8px 16px -4px rgba(15, 23, 42, 0.06), 0 2px 4px -1px rgba(15, 23, 42, 0.03)`.
- **Level 3 (Modal Dialogs & Decision Sheets):** Elevated center-stage plane with a dark slate backdrop scrim at 30% opacity (`rgba(15, 23, 42, 0.3)`) and depth shadow: `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

## Shapes

The geometric signature uses warm, curvature-driven radii that feel human, tactile, and responsive.

### Curvature Assignments
- **Base Components (Inputs, Buttons, Segmented Selectors):** `0.5rem` (`rounded-md` / base level) to provide clear target affordances and neat stacking alignment.
- **Containers & Modular Cards:** `0.75rem` to `1rem` (`rounded-lg` to `rounded-xl`) for main event panels, poll containers, and time slot groupings.
- **Avatars, Badges, & Status Indicators:** Always pill-shaped (`9999px` / `rounded-full`). These circular silhouettes balance the structural grid cards, signaling social participation and live attendance.

## Components

### Buttons & Interactive Controls
- **Primary CTA:** Background `#4F46E5`, foreground `#FFFFFF`, border none, border-radius `0.5rem`. Hover: `#4338CA`. Active state: `#3730A3` with scale down to `0.98`. Typography: `label-lg`.
- **Secondary / Ghost Action:** Background `#FFFFFF`, border `1px solid #E2E8F0`, foreground `#334155`. Hover: background `#F8FAFC`, border `#CBD5E1`.
- **Destructive Action:** Secondary subtle styling with foreground `#E11D48`, background `#FFF1F2`, hover `#FFE4E6`. Reserved for event declination, leave group, or schedule wipe actions.

### RSVP Chips & Attendance Badges
Status chips communicate certainty without sensory overload:
- **Confirmed Attendance:** Height `28px`, padding `0 10px`, radius `9999px`. Background `#DCFCE7`, text `#15803D`, icon color `#16A34A`.
- **Partial Attendance:** Background `#CCFBF1`, text `#0F766E`, icon color `#0D9488`.
- **Awaiting / Pending:** Background `#FEF3C7`, text `#B45309`, icon color `#D97706`.
- **Declined:** Background `#F1F5F9`, text `#64748B`, icon color `#94A3B8`.

### Input Fields & Selectors
- **Default State:** Background `#FFFFFF`, border `1px solid #CBD5E1`, border-radius `0.5rem`, text `#0F172A`, placeholder `#94A3B8`. Height `42px`, horizontal padding `12px`.
- **Focus State:** Border color `#4F46E5`, box-shadow `0 0 0 3px rgba(79, 70, 229, 0.15)`. Outline none.

### Interactive Availability Matrix Cell
- **Unselected / Inactive:** Background `#F8FAFC`, border `1px solid #F1F5F9`. Hover: background `#EEF2F6`.
- **High Concurrency / Best Time:** Background `#10B981` (100% quorum) or graded tints (`#34D399`, `#6EE7B7`, `#A7F3D0` based on proportion), white or dark emerald text corresponding to contrast requirements.
- **Individual Selection State:** Ring indicator `2px solid #4F46E5` overlaying the cell.

### Event Cards
Cards balance clean group metadata with rapid social comprehension:
- White surface `#FFFFFF`, 1px border `#E2E8F0`, radius `0.75rem` (`12px`).
- Header holds title in `headline-sm`, subtitle/location in `body-sm` slate, and top-right pill badge indicating user RSVP status.
- Card footer embeds an overlapping stacked avatar cluster (`28px` circles with `2px` white outline ring) showing confirmed participants alongside an affirmative confirmation tally.